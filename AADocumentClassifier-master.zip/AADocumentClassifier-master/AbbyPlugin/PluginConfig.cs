﻿using System;

namespace AbbyPlugin
{
    class PluginConfig
    {
        private static string bin64folder = "";
        private static string binfolder = "";
        private static string projectid = "";
        private static string licensepath = "";
        private static string licensepwd = "";

        public static void Init(string afrbin64, string afrbin, string projectid, string licensepath, string licensepwd)
        {
            bin64folder = afrbin64;
            binfolder = afrbin;
            PluginConfig.projectid = projectid;
            PluginConfig.licensepath = licensepath;
            PluginConfig.licensepwd = licensepwd;
        }

        // Folder with FRE dll
        public static String GetDllFolder()
        {
            if (is64BitConfiguration())
            {
                return bin64folder;
            }
            else
            {
                return binfolder;
            }
        }

        // Return customer project id for FRE
        public static String GetCustomerProjectId()
        {
            return projectid;
        }

        // Return path to license file
        public static String GetLicensePath()
        {
            var path = "";
            if (!System.IO.File.Exists(path))
                path = licensepath;
            return path;
        }

        // Return license password
        public static String GetLicensePassword()
        {
            return licensepwd;
        }

        // Determines whether the current configuration is a 64-bit configuration
        private static bool is64BitConfiguration()
        {
            return System.IntPtr.Size == 8;
        }
    }
}
