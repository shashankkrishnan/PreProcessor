﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AbbyPlugin
{
    public interface IClassificationData
    {
        string Text { get; }
        string SourceFile { get; }
    }

    public interface IClassifier
    {
        string Name { get; }
        double Classify(IClassificationData data);
    }

    public class ClassifiedPage : IClassificationData
    {
        public ClassifiedPage(string source) { SourceFile = source; }

        public string SourceFile { get; private set; }
        public IClassifier Class { get; set; }
        public string Text { get; set; }
        public int PageNumber { get; set; }
        public double Score { get; set; }
    }

    public class DocumentField : IClassifier
    {
        private List<string> aliases = new List<string>();
        public DocumentField(string name) { Name = name; }
        public string Name { get; private set; }
        public ICollection<string> Aliases
        {
            get
            {
                return aliases.AsReadOnly();
            }
        }

        public void AddAlias(string alias)
        {
            var a = alias.ToLower();
            if (!aliases.Contains(a))
                aliases.Add(a);
        }

        public double Classify(IClassificationData data)
        {
            return Aliases.Any(x =>
            {
                var found = data.Text.Contains(x);
                DocumentProcessor.Logger.WriteLine(LogLevel.Info, found ? LogOps.Found : LogOps.NotFound,
                    string.Format(@"Field '{0}', Alias '{1}'", this.Name, x));
                return found;
            }
            ) ? 1 : 0;
        }
    }
}
