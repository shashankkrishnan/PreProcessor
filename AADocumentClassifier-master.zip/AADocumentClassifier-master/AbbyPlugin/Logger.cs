﻿using System;
using System.Collections.Generic;
using System.IO;

namespace AbbyPlugin
{
    public enum LogLevel
    {
        Info,
        Warning,
        Error,
        StackTrace,
    }

    public enum LogOps
    {
        NotFound,
        Found,
        Classified,
        TextExtracted,
        Exception,
        Command,
        Result
    }

    interface ILogger
    {
        LogLevel LogLevel { get; set; }
        void WriteLine(LogLevel mode, LogOps ops, string log);
    }

    abstract class BaseLogger : ILogger
    {
        public BaseLogger() { LogLevel = LogLevel.Error; }

        public LogLevel LogLevel { get; set; }

        public void WriteLine(LogLevel level, LogOps ops, string log)
        {
            var timestamp = DateTime.Now;
            if (level >= LogLevel)
                WriteLog(string.Format("{0}, [{1} {2}], {3}, {4}", level.ToString(), timestamp.ToShortTimeString(), timestamp.ToShortDateString(), ops.ToString(), log));
        }

        protected abstract void WriteLog(string log);
    }

    class Logger : BaseLogger
    {
        public Logger(string logFile) { LogFile = logFile; }

        public string LogFile { get; private set; }
        
        protected override void WriteLog(string log)
        {
            using(StreamWriter w = File.AppendText(LogFile))
            {
                w.WriteLine(log);
            }
        }
    }

    class ConsoleLogger : BaseLogger
    {
        public ConsoleLogger()
        {
        }

        protected override void WriteLog(string log)
        {
            System.Console.WriteLine(log);
        }
    }
}
