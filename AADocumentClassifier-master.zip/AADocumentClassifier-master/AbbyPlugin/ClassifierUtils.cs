﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace AbbyPlugin
{
    public class ClassifierUtils
    {
        private static DocumentClassifier classifier = null;
        
        /// <summary>
        /// Initializes the Plugin Config to load Abbyy Fine Reader Engine
        /// </summary>
        /// <param name="afrbin64">Bin64 folder in Abbyy finereader SDK installation</param>
        /// <param name="afrbin">Bin folder in Abby finereader SDK installation</param>
        /// <param name="projectid">Customer project id</param>
        /// <param name="licensepath">Abbyy Runtime license path</param>
        /// <param name="licensepwd">License password</param>
        public static void InitPluginConfig(string afrbin64, string afrbin, string projectid, string licensepath, string licensepwd)
        {
            PluginConfig.Init(afrbin64, afrbin, projectid, licensepath, licensepwd);
        }

        /// <summary>
        /// Initializes the classifier with classification rules CSV file and log file details.
        /// </summary>
        /// <param name="classificationRulesCSV">The classification rules CSV file</param>
        /// <param name="logfile">Log file path</param>
        /// <param name="loglevel">Level of logging values between 0-3, lower the number higher
        /// the details are logged.</param>
        public static void InitClassifier(string classificationRulesCSV, string logfile, int loglevel)
        {
            classifier = DocumentClassifier.Create(classificationRulesCSV);
            var processor = new DocumentProcessor();
            processor.Init(logfile, (LogLevel)loglevel);
            classifier.Init(processor);
        }

        /// <summary>
        /// Destroys the initialized classifier and releases all unmanaged resources.
        /// </summary>
        public static void DestroyCLassifier()
        {
            if(classifier != null)
            {
                DocumentClassifier.DestroyClassifier(classifier);
                classifier = null;
            }
        }

        /// <summary>
        /// Classifies all the files in a folder and returns a CSV string of 
        /// the classified result.
        /// </summary>
        /// <param name="folder"></param>
        /// <param name="classificationRulesCSV"></param>
        /// <param name="language"></param>
        /// <param name="logFile"></param>
        /// <param name="logLevel"></param>
        /// <returns></returns>
        public static string ClassifyAllFilesInTheFolder(string folder, string classificationRulesCSV, string language, string logFile = "", int logLevel = 0)
        {
            var classifier = DocumentClassifier.Create(classificationRulesCSV);
            var processor = new DocumentProcessor();
            processor.Init(logFile, (LogLevel)logLevel);
            classifier.Init(processor);

            var directory = new DirectoryInfo(folder);
            var extensions = new[] { ".png", ".pdf", ".jpg", ".jpeg" };
            var files = directory.GetFiles().Where(f => extensions.Contains(f.Extension.ToLower()));
            var sb = new StringBuilder();
            return files.Select(f =>
                    classifier.ClassifyDocument(f.FullName, language))
                    .Aggregate(sb,
                        (s, p) => s.AppendLine(
                            string.Format("\"{0}\",{1},{2}", p.SourceFile, p.Class.Name, p.Score)))
                    .ToString();
        }

        /// <summary>
        /// Classifies a given document based on the classification rules.
        /// </summary>
        /// <param name="filepath">Input pdf or image document path</param>
        /// <param name="language">Primary language of the document</param>
        /// <param name="score">Classification score</param>
        /// <returns>Returns the name of the classified class.</returns>
        public static string ClassifyDocument(string filepath, string language, out double score)
        {
            score = 0.0;
            var classname = "Unclassified";
            if (classifier == null) return classname;
            var page = classifier.ClassifyDocument(filepath, language);
            score = page.Score;
            if (page.Score > 0.25)
                classname = page.Class.Name;

            return classname;
        }

        /// <summary>
        /// Returns a GUID string
        /// </summary>
        public static string CreateGUID()
        {
            return Guid.NewGuid().ToString();
        }

        /// <summary>
        /// Returns page range for split based on the blank pages found in the given document.
        /// </summary>
        /// <param name="filepath">Input Document path</param>
        /// <param name="maxAlphabetLetter">Max number of alphabets allowed in blank page</param>
        /// <param name="maxBlackPercentage">Max percentage(0-100) of black allowed in blank page</param>
        /// <param name="maxTextObjects">Max number of text objects allowed in blank page</param>
        /// <param name="logFile"></param>
        /// <returns>Comma separated list of range strings to be used for splitting.</returns>
        public static string GetBlankPageSplitPageRange(string filepath, int maxAlphabetLetter, int maxBlackPercentage, int maxTextObjects, string logFile)
        {
            using (var processor = new DocumentProcessor())
            {
                processor.Init(logFile, LogLevel.Info);
                DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Command,
                    string.Format("GetBlankPageSplitPageRange: {0}, \"{1}, {2}, {3}\"",
                        filepath, maxAlphabetLetter, maxBlackPercentage, maxTextObjects));

                var sb = new StringBuilder();
                int pagecount = -1;
                int lastsepartor = -1;
                var ranges = processor.GetBlankPages(filepath, out pagecount, maxAlphabetLetter, maxBlackPercentage, maxTextObjects)
                                .Select(i => GetPageRange(i, pagecount, ref lastsepartor))
                                .Concat(Enumerable.Repeat(GetPageRange(pagecount, pagecount, ref lastsepartor), 1))
                                .SkipWhile(s => string.IsNullOrEmpty(s));

                var result = string.Join(",", ranges.ToArray());
                DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Result, result);
                return result;
            }
        }

        private static string GetPageRange(int separatorIndex, int totalpages, ref int lastseparator)
        {
            if (separatorIndex <= 0 || separatorIndex <= lastseparator+1 || separatorIndex >= totalpages) return string.Empty;
            var range = string.Format("{0}-{1}", lastseparator + 2, separatorIndex);
            lastseparator = separatorIndex;
            return range;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filepath"></param>
        /// <param name="maxAlphabetLetter"></param>
        /// <param name="maxBlackPercentage"></param>
        /// <param name="maxTextObjects"></param>
        /// <returns></returns>
        public static string GetBlankPageIndeicesAsCSV(string filepath, int maxAlphabetLetter, int maxBlackPercentage, int maxTextObjects, string logFile)
        {
            using(var processor = new DocumentProcessor())
            {
                processor.Init(logFile, LogLevel.Info);
                DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Command, 
                    string.Format("GetBlankPageIndeicesAsCSV: {0}, \"{1}, {2}, {3}\"", 
                        filepath, maxAlphabetLetter, maxBlackPercentage, maxTextObjects));

                var sb = new StringBuilder();
                int pagecount = -1;
                var result = processor.GetBlankPages(filepath, out pagecount, maxAlphabetLetter, maxBlackPercentage, maxTextObjects)
                    .Aggregate(sb, (s, i) => s.AppendFormat("{0},", i+1))
                    .ToString();

                DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Result, result);
                return result;
            }
        }

        private static void CopyFile(FileInfo item, string folder, string className)
        {
            var destination = Path.Combine(folder, className);
            if (!Directory.Exists(destination))
            {
                Directory.CreateDirectory(destination);
            }
            item.MoveTo(Path.Combine(destination, item.Name));
        }
    }
}
