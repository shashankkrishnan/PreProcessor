﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace AbbyPlugin
{
    public class DocumentClass : IClassifier
    {
        private Dictionary<string, DocumentField> fields = new Dictionary<string, DocumentField>();

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name"></param>
        public DocumentClass(string name) { Name = name; }

        /// <summary>
        /// Name of the DocumentClass
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// List of Parameters in the Document class.
        /// </summary>
        public IEnumerable<DocumentField> Fields { get { return fields.Values; } }

        /// <summary>
        /// Creates a new field and inserts into the list of fields.
        /// </summary>
        /// <param name="name">Name of the field</param>
        /// <returns>DocumentField</returns>
        public DocumentField AddField(string name)
        {
            DocumentField field = null;
            if (!fields.TryGetValue(name, out field))
            {
                field = new DocumentField(name);
                fields.Add(name, field);
            }
            return field;
        }

        /// <summary>
        /// Returns the confidence level or % match for classification
        /// </summary>
        /// <param name="data">Data to classify</param>
        /// <returns></returns>
        public double Classify(IClassificationData data)
        {
            if (!Fields.Any()) return 0.0;

            var score = Fields.Aggregate(0.0, (s, f) => s + f.Classify(data)) / fields.Count;
            DocumentProcessor.Logger.WriteLine(LogLevel.Info, LogOps.Classified, string.Format(@"Class '{0}', score '{1}'", this.Name, score));
            return score;
        }
    }

    public class OtherClass : IClassifier
    {
        private double score = 0.8;
        public OtherClass(string name, double score)
        {
            this.score = score;
            this.Name = name;
        }

        public string Name { get; private set; }

        public double Classify(IClassificationData data)
        {
            return score; //Classification threashold
        }
    }

    public class DocumentClassifier
    {
        protected Dictionary<string, DocumentClass> classes = new Dictionary<string, DocumentClass>();
        private DocumentProcessor documentProcessor = null;

        protected DocumentClassifier() { }

        /// <summary>
        /// Creates an instance of DocumentClassifier class and initializes it using the rules CSV file
        /// </summary>
        /// <param name="classificationRulesCSV">Path for classification rules CSV</param>
        /// <returns>DocumentClassifier object</returns>
        public static DocumentClassifier Create(string classificationRulesCSV)
        {
            var classifier = new DocumentClassifier();
            if (string.IsNullOrEmpty(classificationRulesCSV)) return classifier;

            using(var reader = new StreamReader(classificationRulesCSV))
            {
                bool skipline = true;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    if (string.IsNullOrEmpty(line)) continue;

                    if (skipline)
                    {
                        skipline = false; //Skip the header row.
                        continue;
                    }

                    var values = line.Split(',');
                    var c = classifier.TryAddClass(values[2]);
                    var f = c.AddField(values[0]);
                    var aliases = values[1].Split('|');
                    foreach (var item in aliases)
                    {
                        f.AddAlias(item);
                    }
                }
            }
            return classifier;
        }

        /// <summary>
        /// Destroys the given instance of the classifier and releases all the resources.
        /// </summary>
        /// <param name="classifier">The classifier to destroy</param>
        public static void DestroyClassifier(DocumentClassifier classifier)
        {
            if (classifier == null)
                return;

            if (classifier.documentProcessor != null)
            {
                classifier.documentProcessor.Dispose();
                classifier.documentProcessor = null;
            }

            classifier.classes.Clear();
        }

        /// <summary>
        /// Initializes the classifier with a document processor. If initialized 
        /// with DocumentProcessor, the classifier instance must be destroyed 
        /// using DestroyClassifier method.
        /// </summary>
        /// <param name="processor">A valid document processor</param>
        public void Init(DocumentProcessor processor)
        {
            documentProcessor = processor;
        }

        public DocumentClass TryAddClass(string name)
        {
            DocumentClass cl = null;
            if(!classes.TryGetValue(name, out cl))
            {
                cl = new DocumentClass(name);
                classes.Add(name, cl);
            }
            return cl;
        }

        public IEnumerable<ClassifiedPage> ClassifyPages(string documentPath, string language)
        {
            bool createProcessor = documentProcessor == null;
            if (createProcessor)
            {
                documentProcessor = new DocumentProcessor();
                documentProcessor.Init(string.Empty);
            }
            try
            {
                return ClassifiedPages(documentProcessor, documentPath, language);
            }
            finally
            {
                if (createProcessor)
                {
                    documentProcessor.Dispose();
                    documentProcessor = null;
                }
            }
        }

        virtual protected IEnumerable<ClassifiedPage> ClassifiedPages(DocumentProcessor processor, string documentPath, string language)
        {
            var texts = processor.GetExtractedTexts(documentPath, language);
            var results = new List<ClassifiedPage>();
            int count = 1;
            foreach (var item in texts)
            {
                IClassificationData data = new ClassifiedPage(documentPath) { Text = item, PageNumber = count++ };

                var page = ClassifyText(data);
                if (page == null) continue;

                results.Add(page);
            }

            return results;
        }

        public ClassifiedPage ClassifyDocument(string documentPath, string language, string destinationFile = "")
        {
            bool createProcessor = documentProcessor == null;
            if (createProcessor)
            {
                documentProcessor = new DocumentProcessor();
                documentProcessor.Init(string.Empty);
            }
            try
            {
                var texts = documentProcessor.GetExtractedTexts(documentPath, language, destinationFile);
                var data = new ClassifiedPage(destinationFile) { Text = string.Join(" ", texts.ToArray()) };
                return ClassifyText(data);
            }
            finally
            {
                if (createProcessor)
                {
                    documentProcessor.Dispose();
                    documentProcessor = null;
                }
            }
        }

        public ClassifiedPage ClassifyText(IClassificationData data)
        {
            var result = classes.Select(item =>
                                            new ClassifiedPage(data.SourceFile)
                                            {
                                                Text = data.Text,
                                                Class = item.Value,
                                                Score = item.Value.Classify(data)
                                            }).OrderByDescending(p => p.Score).FirstOrDefault();

            return result;
        }
    }

    class BlankPageClassifier : DocumentClassifier
    {
        int maxAlphabetLetter =20, maxBlackPercentage = 10, maxTextObjects = 50;
        public BlankPageClassifier() { }
        public BlankPageClassifier(int maxAlphabetLetter, int maxBlackPercentage, int maxTextObjects) : base()
        {
            this.maxAlphabetLetter = maxAlphabetLetter;
            this.maxBlackPercentage = maxBlackPercentage;
            this.maxTextObjects = maxTextObjects;
        }

        protected override IEnumerable<ClassifiedPage> ClassifiedPages(DocumentProcessor processor, string documentPath, string language)
        {
            var score = 0.8;
            var cl = new OtherClass("Blank", score);
            int pagecount = -1;
            return processor.GetBlankPages(documentPath, out pagecount, maxAlphabetLetter, maxBlackPercentage, maxTextObjects)
                    .Select(i => new ClassifiedPage(documentPath) { Class = cl, PageNumber = i + 1, Score = score, Text = string.Empty });
        }
    }
}
