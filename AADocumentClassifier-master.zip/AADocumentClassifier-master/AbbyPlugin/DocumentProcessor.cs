﻿using FREngine;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace AbbyPlugin
{
    public class DocumentProcessor : IDisposable
    {
        private EngineLoader engineLoader = null;

        public void Init(string logfile, LogLevel logLevel = LogLevel.Info)
        {
            engineLoader = SetupEngineLoader();
            SetLogFile(logfile, logLevel);
        }

        internal static ILogger Logger = new ConsoleLogger();
        internal static void SetLogFile(string logfile, LogLevel logLevel = LogLevel.Info)
        {
            if (!string.IsNullOrEmpty(logfile))
                Logger = new Logger(logfile) { LogLevel = logLevel };
            else
                Logger = new ConsoleLogger();
        }

        public static void WriteLog(LogLevel level, LogOps ops, string log)
        {
            Logger.WriteLine(level, ops, log);
        }

        private static EngineLoader SetupEngineLoader()
        {
            var engineLoader = new EngineLoader();
            engineLoader.Engine.LoadPredefinedProfile("DocumentConversion_Accuracy");
            // Possible profile names are:
            //   "DocumentConversion_Accuracy", "DocumentConversion_Speed",
            //   "DocumentArchiving_Accuracy", "DocumentArchiving_Speed",
            //   "BookArchiving_Accuracy", "BookArchiving_Speed",
            //   "TextExtraction_Accuracy", "TextExtraction_Speed",
            //   "FieldLevelRecognition",
            //   "BarcodeRecognition_Accuracy", "BarcodeRecognition_Speed",
            //   "HighCompressedImageOnlyPdf",
            //   "BusinessCardsProcessing",
            //   "EngineeringDrawingsProcessing",
            //   "Version9Compatibility",
            //   "Default"

            return engineLoader;
        }

        /// <summary>
        /// Exports the given source file to editable PDF by OCR processing
        /// </summary>
        /// <param name="sourcefile">Source File</param>
        /// <param name="destinationfile">Destination File</param>
        /// <param name="language">Language of the source file</param>
        /// <returns>Status code: 0 for success, -1 for failure.</returns>
        public int ExportToEditablePDF(string sourcefile, string destinationfile, string language)
        {
            // Don't recognize PDF file with a textual content, just copy it
            if (engineLoader.Engine.IsPdfWithTextualContent(sourcefile, null))
            {
                File.Copy(sourcefile, destinationfile, true);
                return 0;
            }

            var document = engineLoader.Engine.CreateFRDocument();

            try
            {
                document.AddImageFile(sourcefile);
                var processingParams = engineLoader.Engine.CreateDocumentProcessingParams();
                processingParams.PageProcessingParams.PagePreprocessingParams.CorrectOrientation = true;

                if (!string.IsNullOrEmpty(language))
                {
                    processingParams.PageProcessingParams.RecognizerParams.SetPredefinedTextLanguage(language);
                }

                document.Process(processingParams);

                // Save results to pdf using 'balanced' scenario
                FREngine.PDFExportParams pdfParams = engineLoader.Engine.CreatePDFExportParams();
                pdfParams.Scenario = FREngine.PDFExportScenarioEnum.PES_Balanced;
                document.Export(destinationfile, FREngine.FileExportFormatEnum.FEF_PDF, pdfParams);
            }
            catch (Exception error)
            {
                Console.WriteLine("ERROR: " + error.Message);
                return -1;
            }
            finally
            {
                document.Close();
            }
            return 0;
        }

        public int[] GetBlankPages(string sourceFile, out int totalPages, int maxAlphabetLetter = 20, int maxBlackPercentage = 10, int maxTextObjects = 50)
        {
            Logger.WriteLine(LogLevel.Info, LogOps.Command, string.Format("GetBlankPages Started, {0}", sourceFile));
            var engine = engineLoader.Engine;
            engine.LoadPredefinedProfile("TextExtraction_Speed");
            var document = engine.CreateFRDocument();
            var emptyPageDetectionParam = engineLoader.Engine.CreateEmptyPageDetectionParams();
            emptyPageDetectionParam.MaxAlphabetLetters = maxAlphabetLetter;
            emptyPageDetectionParam.MaxBlackPercentage = maxBlackPercentage;
            emptyPageDetectionParam.MaxTextObjects = maxTextObjects;

            try
            {
                if (!File.Exists(sourceFile))
                    throw new ArgumentException(string.Format("'{0}' file doesn't exist!!", sourceFile));
                
                document.AddImageFile(sourceFile);

                var emptyPages = new List<int>();
                totalPages = document.Pages.Count;
                foreach (FRPage page in document.Pages)
                {
                    if (page.IsEmpty(null, null, emptyPageDetectionParam))
                        emptyPages.Add(document.Pages.IndexOf(page));
                }

                return emptyPages.ToArray();
            }
            catch (Exception exception)
            {
                Logger.WriteLine(LogLevel.Error, LogOps.Exception, exception.Message);
                Logger.WriteLine(LogLevel.StackTrace, LogOps.Exception, exception.StackTrace);
                totalPages = -1;
                return Enumerable.Empty<int>().ToArray();
            }
            finally
            {
                document.Close();
                Logger.WriteLine(LogLevel.Info, LogOps.Command, string.Format("GetBlankPages Completed, {0}", sourceFile));
            }
        }

        public List<string> GetExtractedTexts(string sourceFile, string language, string destinationFile = "")
        {
            var engine = engineLoader.Engine;
            engine.LoadPredefinedProfile("TextExtraction_Accuracy");
            var document = engine.CreateFRDocument();

            try
            {
                document.AddImageFile(sourceFile);
                var processingParams = engineLoader.Engine.CreateDocumentProcessingParams();
                processingParams.PageProcessingParams.PagePreprocessingParams.CorrectOrientation = true;

                if (!string.IsNullOrEmpty(language))
                {
                    processingParams.PageProcessingParams.RecognizerParams.SetPredefinedTextLanguage(language);
                }

                document.Process(processingParams);
                var texts = new List<string>();
                foreach (IFRPage page in document.Pages)
                {
                    texts.Add(page.Layout.TextAsString);
                }

                if (!string.IsNullOrEmpty(destinationFile))
                {
                    // Save results to pdf using 'balanced' scenario
                    FREngine.PDFExportParams pdfParams = engineLoader.Engine.CreatePDFExportParams();
                    pdfParams.Scenario = FREngine.PDFExportScenarioEnum.PES_Balanced;
                    Path.ChangeExtension(destinationFile, ".pdf");
                    document.Export(destinationFile, FREngine.FileExportFormatEnum.FEF_PDF, pdfParams);
                }
                return texts;
            }
            catch(Exception exception)
            {
                Logger.WriteLine(LogLevel.Error, LogOps.Exception, exception.Message);
                Logger.WriteLine(LogLevel.StackTrace, LogOps.Exception, exception.StackTrace);
                return new List<string>();
            }
            finally
            {
                document.Close();
            }
        }

        internal bool CheckSimilarity(string file1, string file2)
        {
            var classEngine = engineLoader.Engine.CreateClassificationEngine();

            var doc = engineLoader.Engine.CreateFRDocument();
            doc.AddImageFile(file1, null, null);

            //Create the classification object
            var classobj = classEngine.CreateObjectFromDocument(doc);
            classobj.Description = "FILE1 Type";

            var trainingData = classEngine.CreateTrainingData();
            var categories = trainingData.Categories;
            var category = categories.AddNew("FILE1");

            category.Objects.Add(classobj);

            var trainer = classEngine.CreateTrainer();
            trainer.TrainingParams.ClassifierType = (int)FREngine.ClassifierTypeEnum.CT_Image;
            var results = trainer.TrainModel(trainingData);

            double F1 = results[0].ValidationResult.FMeasure;
            var model = results[0].Model;

            var doc2 = engineLoader.Engine.CreateFRDocument();
            doc2.AddImageFile(file2);
            var clobj2 = classEngine.CreateObjectFromDocument(doc2);
            var clresults = model.Classify(clobj2);

            doc.Close();
            doc2.Close();

            return clresults[0].Probability > 0.8;
        }

        public void Dispose()
        {
            if (engineLoader != null) engineLoader.Dispose();
            engineLoader = null;
        }
    }
}
