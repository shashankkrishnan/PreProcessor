﻿using AbbyPlugin;
using NDesk.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace AADocumentClassifier
{
    class Program
    {
        enum Operations
        {
            Classify,
            Categorize,
            Convert,
            ExtractText,
            BlankPages,
            None
        }

        static void Main(string[] args)
        {
            Operations ops = Operations.None;
            string language = "";
            string logFile = "debug.log";
            bool showHelp = false;
            bool allpages = false;

            var options = new OptionSet()
            {
                {"cl|classify", @"Classifies the given file!, usage --cl -l=[language] [source] [rulesfile]", v=> ops = Operations.Classify },
                {"ct|categorize", @"Categorizes files from a the given folder to sub-folder based on the document class, usage --ct -l=[language] [sourceFolder] [rulesfile] [destinationFolder]", v=> ops = Operations.Categorize },
                {"cv|convert", "Converts the given file to a readable PDF file, usage --cv [source] [destination]", v=> ops = Operations.Convert },
                {"ocr", "Converts all the files in the given folder to readable PDF files and copy them to destination folder, usage --ocr [sourceFolder] [destinationFolder]", v=> ops = Operations.Convert },
                {"ex|extract", "Extracts text from the given file, usage --ex [source] [destination]", v=> ops = Operations.ExtractText },
                {"bl|blank", "Get a list of blank pages in the given file, usage --bl [source]", v=> ops = Operations.BlankPages },
                {"l|language=", "{LANGUAGE} of the file", v=> language = v },
                {"a|all", "Classify all pages as one class", v=> allpages = v!= null },
                {"log=", "{LOG FILE}", v=> logFile = v },
                {"h|help", "Shows Help message and exits", v=> showHelp = v != null }
            };

            List<string> extra = new List<string>();
            try
            {
                extra = options.Parse(args);
            }
            catch (OptionException e)
            {
                Console.WriteLine("AADocumentClassifier Failure: {0}", e.Message);
                Console.WriteLine("Try AADocumentClassifier --help for more information!");
            }
            if (showHelp || !args.Any())
            {
                ShowHelp(options);
                return;
            }

            DocumentProcessor docProcessor = new DocumentProcessor();
            docProcessor.Init(logFile);

            DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Command, string.Format("{0}, {1}", ops.ToString(), string.Join(" ", args)));
            switch (ops)
            {
                case Operations.Classify:
                    ClassifyFile(extra, language, allpages, docProcessor, options);
                    break;
                case Operations.Categorize:
                    CategorizeFilesInTheFolder(extra, language, docProcessor, options);
                    break;
                case Operations.Convert:
                    ConvertOCR(extra, language, docProcessor, options);
                    break;
                case Operations.ExtractText:
                    ExtractText(extra, language, docProcessor, options);
                    break;
                case Operations.BlankPages:
                    GetBlankPages(extra, language, docProcessor, options);
                    break;
                case Operations.None:
                default:
                    break;
            }

            if(docProcessor != null)
                docProcessor.Dispose();
        }

        private static void GetBlankPages(List<string> extra, string language, DocumentProcessor processor, OptionSet options)
        {
            if (extra.Count < 1)
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.Command, "Wrong Arguments!");
                Console.WriteLine("Wrong number of arguments!");
                ShowHelp(options);
                return;
            }

            if (!File.Exists(extra[0]))
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.NotFound, string.Format("File {0}", extra[0]));
                Console.WriteLine("ERROR: File {0} not found!", extra[0]);
                return;
            }
            int pagecount = -1;
            var pages = processor.GetBlankPages(extra[0], out pagecount);
            DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Result, pages.Aggregate("", (s, p) => string.Format("{0}, {1}", s, p)));
        }

        private static void CategorizeFilesInTheFolder(List<string> extra, string language, DocumentProcessor processor, OptionSet options)
        {
            if (extra.Count < 2)
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.Command, "Wrong Arguments!");
                Console.WriteLine("Wrong number of arguments!");
                ShowHelp(options);
                return;
            }

            if (!Directory.Exists(extra[0]))
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.NotFound, string.Format("Directory {0}", extra[0]));
                Console.WriteLine("ERROR: Directory {0} not found!", extra[0]);
                return;
            }

            if (!File.Exists(extra[1]))
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.NotFound, string.Format("Directory {0}", extra[0]));
                Console.WriteLine("ERROR: Directory {0} not found!", extra[0]);
                return;
            }

            var destinationFolder = extra.Count > 2 ? extra[2] : extra[0];

            var classifier = DocumentClassifier.Create(extra[1]);
            classifier.Init(processor);

            var directory = new DirectoryInfo(extra[0]);
            var extensions = new[] { ".png", ".pdf", ".jpg", ".jpeg" };
            var files = directory.GetFiles().Where(f => extensions.Contains(f.Extension.ToLower()));
            var tmpfolder = Path.GetTempPath();
            foreach (var item in files)
            {
                var tmpfile = Path.Combine(tmpfolder, item.Name);
                var page = classifier.ClassifyDocument(item.FullName, language, tmpfile);
                var log = string.Format("File '{0}', Class: {1}, Score: {2}", item.Name, page.Class.Name, page.Score);
                DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Classified, log);
                Console.WriteLine("Classified {0}", log);
                CopyFile(new FileInfo(tmpfile), destinationFolder, page.Score >= 0.4 ? page.Class.Name : "Unclassified");
            }
            File.Create(Path.Combine(directory.FullName, "CategorizationComplete.txt"));
        }

        private static void CopyFile(FileInfo item, string folder, string className)
        {
            var destination = Path.Combine(folder, className);
            if (!Directory.Exists(destination))
            {
                Directory.CreateDirectory(destination);
            }
            item.MoveTo(Path.Combine(destination, item.Name));
        }

        private static void ExtractText(List<string> extra, string language, DocumentProcessor processor, OptionSet options)
        {
            if (extra.Count < 1)
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.Command, "Wrong Arguments!");
                Console.WriteLine("Wrong number of arguments!");
                ShowHelp(options);
                return;
            }

            if (!File.Exists(extra[0]))
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.NotFound, string.Format("File {0}", extra[0]));
                Console.WriteLine("ERROR: File {0} not found!", extra[0]);
                return;
            }
            var texts = processor.GetExtractedTexts(extra[0], language);
            DocumentProcessor.WriteLog(LogLevel.Info, LogOps.TextExtracted, string.Join(",", texts.ToArray()));
        }

        private static void ConvertOCR(List<string> extra, string language, DocumentProcessor processor, OptionSet options)
        {
            if (extra.Count < 2)
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.Command, "Wrong Arguments!");
                Console.WriteLine("Wrong number of arguments!");
                ShowHelp(options);
                return;
            }

            if (Directory.Exists(extra[0]))
            {
                var directory = new DirectoryInfo(extra[0]);
                var extensions = new[] { ".png", ".pdf" };
                var files = directory.GetFiles().Where(f => extensions.Contains(f.Extension.ToLower()));
                foreach (var item in files)
                {
                    var destination = Path.Combine(extra[1], item.Name);
                    var status = processor.ExportToEditablePDF(item.FullName, destination, language);
                    if (status == 0)
                        DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Command, string.Format("PDF Export to {0}", destination));
                }
            }

            if (!File.Exists(extra[0]))
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.NotFound, string.Format("Directory {0}", extra[0]));
                Console.WriteLine("ERROR: Directory {0} not found!", extra[0]);
                return;
            }

            processor.ExportToEditablePDF(extra[0], extra[1], language);
            DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Command, "PDF Exported!!");
        }

        private static void ClassifyFile(List<string> extra, string language, bool allpages, DocumentProcessor processor, OptionSet options)
        {
            if (extra.Count < 2)
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.Command, "Wrong Arguments!");
                Console.WriteLine("Wrong number of arguments!");
                ShowHelp(options);
                return;
            }

            if (!File.Exists(extra[0]))
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.NotFound, string.Format("Directory {0}", extra[0]));
                Console.WriteLine("ERROR: Directory {0} not found!", extra[0]);
                return;
            }

            if (!File.Exists(extra[1]))
            {
                DocumentProcessor.WriteLog(LogLevel.Error, LogOps.NotFound, string.Format("Directory {0}", extra[0]));
                Console.WriteLine("ERROR: Directory {0} not found!", extra[0]);
                return;
            }

            var classifier = DocumentClassifier.Create(extra[1]);
            classifier.Init(processor);
            if (allpages)
            {
                var page = classifier.ClassifyDocument(extra[0], language);
                var log = string.Format("File '{0}', Class: {1}, Score: {2}", extra[0], page.Class.Name, page.Score);
                DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Classified, log);
                Console.WriteLine("Classified {0}", log);
            }
            else
            {
                var pages = classifier.ClassifyPages(extra[0], language);
                foreach (var item in pages)
                {
                    var log = string.Format("File '{0}', Class: {1}, Score: {2}, Page: {3}", extra[0], item.Class.Name, item.Score, item.PageNumber + 1);
                    DocumentProcessor.WriteLog(LogLevel.Info, LogOps.Classified, log);
                    Console.WriteLine("Classified {0}", log);
                }
            }
        }

        private static void ShowHelp(OptionSet options)
        {
            Console.WriteLine("Usage: AADocumentClassifier [OPTIONS]+ [source] [destination]");
            Console.WriteLine();
            Console.WriteLine("Options:");
            options.WriteOptionDescriptions(Console.Out);
        }
    }
}
